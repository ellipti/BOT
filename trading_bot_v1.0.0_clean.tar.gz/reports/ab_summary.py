#!/usr/bin/env python3
"""
A/B Experiment Summary Report Generator

Generates comprehensive reports comparing experiment arms with key performance indicators.
Outputs both CSV data and Markdown summary reports.
"""

import csv
import json
import logging
import statistics
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import yaml

from observability.metrics import get_metrics

logger = logging.getLogger(__name__)


class ABSummaryReporter:
    """Generates A/B experiment summary reports"""
    
    def __init__(self, config_path: str = "configs/experiments.yaml", output_dir: str = "reports"):
        self.config_path = config_path
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        self.config = self._load_config()
        self.metrics = get_metrics()
        
    def _load_config(self) -> Dict:
        """Load experiment configuration"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except Exception as e:
            logger.error(f"Failed to load experiment config: {e}")
            return {}
    
    def generate_report(self, hours_back: int = 24) -> Dict:
        """
        Generate comprehensive A/B experiment report
        
        Args:
            hours_back: How many hours of data to analyze
            
        Returns:
            Report data dictionary
        """
        logger.info(f"Generating A/B experiment report (last {hours_back} hours)")
        
        # Calculate time window
        end_time = datetime.now(timezone.utc)
        start_time = end_time - timedelta(hours=hours_back)
        
        # Collect experiment data
        experiment_name = self.config.get("name", "unknown")
        arms = list(self.config.get("arms", {}).keys())
        
        report_data = {
            "experiment": experiment_name,
            "time_window": {
                "start": start_time.isoformat(),
                "end": end_time.isoformat(),
                "hours": hours_back
            },
            "arms": {},
            "summary": {},
            "recommendations": []
        }
        
        # Generate per-arm statistics
        for arm in arms:
            arm_data = self._analyze_arm_performance(arm, start_time, end_time)
            report_data["arms"][arm] = arm_data
        
        # Generate comparative summary
        report_data["summary"] = self._generate_comparative_summary(report_data["arms"])
        
        # Generate recommendations
        report_data["recommendations"] = self._generate_recommendations(report_data)
        
        # Save reports
        self._save_csv_report(report_data)
        self._save_markdown_report(report_data)
        self._save_json_report(report_data)
        
        return report_data
    
    def _analyze_arm_performance(self, arm: str, start_time: datetime, end_time: datetime) -> Dict:
        """Analyze performance metrics for a specific experiment arm"""
        
        # Mock data collection - in real implementation, this would query
        # the metrics collector or database for actual experiment data
        
        # For now, generate realistic sample data
        import random
        random.seed(hash(arm))  # Consistent data per arm
        
        total_signals = random.randint(50, 200)
        total_trades = int(total_signals * random.uniform(0.6, 0.9))  # 60-90% conversion
        winning_trades = int(total_trades * random.uniform(0.45, 0.65))  # 45-65% win rate
        losing_trades = total_trades - winning_trades
        
        # Generate trade results
        avg_win = random.uniform(50, 150)  # Average win in points
        avg_loss = random.uniform(30, 80)  # Average loss in points
        
        total_pnl = (winning_trades * avg_win) - (losing_trades * avg_loss)
        win_rate = winning_trades / total_trades if total_trades > 0 else 0
        
        # Calculate profit factor
        gross_profit = winning_trades * avg_win
        gross_loss = losing_trades * avg_loss
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')
        
        # Order execution metrics
        rejected_orders = int(total_trades * random.uniform(0.01, 0.08))  # 1-8% rejection
        rejection_rate = rejected_orders / (total_trades + rejected_orders) if (total_trades + rejected_orders) > 0 else 0
        
        fill_latencies = [random.uniform(100, 3000) for _ in range(total_trades)]
        fill_latency_p95 = statistics.quantiles(fill_latencies, n=20)[18] if fill_latencies else 0  # 95th percentile
        
        # Risk metrics
        max_drawdown = random.uniform(0.005, 0.025)  # 0.5-2.5% max drawdown
        current_drawdown = random.uniform(0, max_drawdown * 0.7)
        
        return {
            "signals": {
                "total": total_signals,
                "converted_to_trades": total_trades,
                "conversion_rate": total_trades / total_signals if total_signals > 0 else 0
            },
            "trades": {
                "total": total_trades,
                "winning": winning_trades,
                "losing": losing_trades,
                "win_rate": win_rate,
                "avg_win_points": avg_win,
                "avg_loss_points": avg_loss
            },
            "pnl": {
                "total_points": total_pnl,
                "gross_profit": gross_profit,
                "gross_loss": gross_loss,
                "profit_factor": profit_factor
            },
            "execution": {
                "orders_placed": total_trades + rejected_orders,
                "orders_filled": total_trades,
                "orders_rejected": rejected_orders,
                "rejection_rate": rejection_rate,
                "fill_latency_avg_ms": statistics.mean(fill_latencies) if fill_latencies else 0,
                "fill_latency_p95_ms": fill_latency_p95
            },
            "risk": {
                "max_drawdown_pct": max_drawdown * 100,
                "current_drawdown_pct": current_drawdown * 100,
                "sharpe_ratio": random.uniform(0.5, 2.5)  # Mock Sharpe ratio
            }
        }
    
    def _generate_comparative_summary(self, arms_data: Dict) -> Dict:
        """Generate comparative summary between arms"""
        if len(arms_data) < 2:
            return {"error": "Need at least 2 arms for comparison"}
        
        arm_names = list(arms_data.keys())
        arm_a, arm_b = arm_names[0], arm_names[1]
        
        data_a = arms_data[arm_a]
        data_b = arms_data[arm_b]
        
        # Calculate performance differences
        win_rate_diff = data_b["trades"]["win_rate"] - data_a["trades"]["win_rate"]
        pf_diff = data_b["pnl"]["profit_factor"] - data_a["pnl"]["profit_factor"]
        rejection_diff = data_b["execution"]["rejection_rate"] - data_a["execution"]["rejection_rate"]
        latency_diff = data_b["execution"]["fill_latency_p95_ms"] - data_a["execution"]["fill_latency_p95_ms"]
        
        # Determine statistical significance (mock calculation)
        sample_size_a = data_a["trades"]["total"]
        sample_size_b = data_b["trades"]["total"]
        
        # Simple significance test (would use proper statistical tests in production)
        min_sample_size = 30
        is_significant = sample_size_a >= min_sample_size and sample_size_b >= min_sample_size
        
        # Determine winner
        winner = None
        if is_significant:
            if win_rate_diff > 0.05 and pf_diff > 0.2:  # B is clearly better
                winner = arm_b
            elif win_rate_diff < -0.05 and pf_diff < -0.2:  # A is clearly better
                winner = arm_a
        
        return {
            "comparison": {
                f"{arm_b}_vs_{arm_a}": {
                    "win_rate_diff": win_rate_diff,
                    "profit_factor_diff": pf_diff,
                    "rejection_rate_diff": rejection_diff,
                    "latency_p95_diff_ms": latency_diff
                }
            },
            "statistical_significance": {
                "is_significant": is_significant,
                "sample_size_a": sample_size_a,
                "sample_size_b": sample_size_b,
                "min_required": min_sample_size
            },
            "winner": winner,
            "confidence": "high" if is_significant else "low"
        }
    
    def _generate_recommendations(self, report_data: Dict) -> List[str]:
        """Generate actionable recommendations based on report data"""
        recommendations = []
        
        summary = report_data.get("summary", {})
        arms_data = report_data.get("arms", {})
        
        # Check sample size
        if not summary.get("statistical_significance", {}).get("is_significant", False):
            recommendations.append("⚠️ Need more data - continue experiment to reach statistical significance")
        
        # Check for clear winner
        winner = summary.get("winner")
        if winner:
            recommendations.append(f"✅ Arm {winner} shows superior performance - consider full rollout")
        else:
            recommendations.append("🤔 No clear winner - consider extending experiment duration")
        
        # Check execution quality
        for arm, data in arms_data.items():
            rejection_rate = data.get("execution", {}).get("rejection_rate", 0)
            if rejection_rate > 0.05:  # >5% rejection rate
                recommendations.append(f"🚨 Arm {arm} has high rejection rate ({rejection_rate:.1%}) - investigate execution issues")
            
            fill_latency = data.get("execution", {}).get("fill_latency_p95_ms", 0)
            if fill_latency > 2000:  # >2s P95 latency
                recommendations.append(f"⏱️ Arm {arm} has slow fill latency ({fill_latency:.0f}ms P95) - optimize execution")
        
        # Check risk metrics
        for arm, data in arms_data.items():
            drawdown = data.get("risk", {}).get("max_drawdown_pct", 0)
            if drawdown > 3.0:  # >3% drawdown
                recommendations.append(f"📉 Arm {arm} has high drawdown ({drawdown:.1f}%) - review risk management")
        
        return recommendations
    
    def _save_csv_report(self, report_data: Dict) -> None:
        """Save detailed data in CSV format"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_path = self.output_dir / f"ab_experiment_{timestamp}.csv"
        
        try:
            with open(csv_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                
                # Header
                writer.writerow([
                    "arm", "total_signals", "total_trades", "win_rate", "profit_factor",
                    "rejection_rate", "fill_latency_p95_ms", "max_drawdown_pct"
                ])
                
                # Data rows
                for arm, data in report_data.get("arms", {}).items():
                    writer.writerow([
                        arm,
                        data["signals"]["total"],
                        data["trades"]["total"],
                        f"{data['trades']['win_rate']:.3f}",
                        f"{data['pnl']['profit_factor']:.2f}",
                        f"{data['execution']['rejection_rate']:.4f}",
                        f"{data['execution']['fill_latency_p95_ms']:.1f}",
                        f"{data['risk']['max_drawdown_pct']:.2f}"
                    ])
            
            logger.info(f"CSV report saved: {csv_path}")
            
        except Exception as e:
            logger.error(f"Failed to save CSV report: {e}")
    
    def _save_markdown_report(self, report_data: Dict) -> None:
        """Save summary report in Markdown format"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        md_path = self.output_dir / f"ab_summary_{timestamp}.md"
        
        try:
            with open(md_path, 'w', encoding='utf-8') as f:
                experiment_name = report_data.get("experiment", "Unknown")
                time_window = report_data.get("time_window", {})
                
                # Header
                f.write(f"# A/B Experiment Report: {experiment_name}\n\n")
                f.write(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}\n\n")
                f.write(f"**Time Window:** {time_window.get('hours', 0)} hours\n\n")
                
                # Performance Summary Table
                f.write("## Performance Summary\n\n")
                f.write("| Arm | Signals | Trades | Win Rate | Profit Factor | Rejection Rate | Fill Latency P95 |\n")
                f.write("|-----|---------|--------|----------|---------------|----------------|------------------|\n")
                
                for arm, data in report_data.get("arms", {}).items():
                    f.write(f"| {arm} | {data['signals']['total']} | {data['trades']['total']} | "
                           f"{data['trades']['win_rate']:.1%} | {data['pnl']['profit_factor']:.2f} | "
                           f"{data['execution']['rejection_rate']:.2%} | {data['execution']['fill_latency_p95_ms']:.0f}ms |\n")
                
                # Statistical Significance
                f.write("\n## Statistical Analysis\n\n")
                summary = report_data.get("summary", {})
                significance = summary.get("statistical_significance", {})
                
                f.write(f"- **Statistically Significant:** {'Yes' if significance.get('is_significant') else 'No'}\n")
                f.write(f"- **Confidence Level:** {summary.get('confidence', 'unknown').title()}\n")
                
                winner = summary.get("winner")
                if winner:
                    f.write(f"- **Recommended Winner:** Arm {winner}\n")
                
                # Recommendations
                f.write("\n## Recommendations\n\n")
                for rec in report_data.get("recommendations", []):
                    f.write(f"- {rec}\n")
                
                # Detailed Metrics
                f.write("\n## Detailed Metrics\n\n")
                for arm, data in report_data.get("arms", {}).items():
                    f.write(f"### Arm {arm}\n\n")
                    
                    # Trading Performance
                    f.write("**Trading Performance:**\n")
                    f.write(f"- Win Rate: {data['trades']['win_rate']:.1%}\n")
                    f.write(f"- Profit Factor: {data['pnl']['profit_factor']:.2f}\n")
                    f.write(f"- Total PnL: {data['pnl']['total_points']:.1f} points\n")
                    
                    # Execution Quality
                    f.write("\n**Execution Quality:**\n")
                    f.write(f"- Rejection Rate: {data['execution']['rejection_rate']:.2%}\n")
                    f.write(f"- Avg Fill Latency: {data['execution']['fill_latency_avg_ms']:.0f}ms\n")
                    f.write(f"- P95 Fill Latency: {data['execution']['fill_latency_p95_ms']:.0f}ms\n")
                    
                    # Risk Metrics
                    f.write("\n**Risk Metrics:**\n")
                    f.write(f"- Max Drawdown: {data['risk']['max_drawdown_pct']:.2f}%\n")
                    f.write(f"- Current Drawdown: {data['risk']['current_drawdown_pct']:.2f}%\n")
                    f.write(f"- Sharpe Ratio: {data['risk']['sharpe_ratio']:.2f}\n\n")
            
            logger.info(f"Markdown report saved: {md_path}")
            
        except Exception as e:
            logger.error(f"Failed to save Markdown report: {e}")
    
    def _save_json_report(self, report_data: Dict) -> None:
        """Save complete report data in JSON format"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        json_path = self.output_dir / f"ab_data_{timestamp}.json"
        
        try:
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(report_data, f, indent=2, default=str)
            
            logger.info(f"JSON report saved: {json_path}")
            
        except Exception as e:
            logger.error(f"Failed to save JSON report: {e}")


def generate_ab_report(hours_back: int = 24) -> Dict:
    """
    Generate A/B experiment report
    
    Args:
        hours_back: Hours of data to analyze
        
    Returns:
        Report data
    """
    reporter = ABSummaryReporter()
    return reporter.generate_report(hours_back)


if __name__ == "__main__":
    # Generate a sample report
    print("🔍 Generating A/B Experiment Report...")
    
    reporter = ABSummaryReporter()
    report_data = reporter.generate_report(hours_back=24)
    
    print(f"✅ Report generated for experiment: {report_data['experiment']}")
    print(f"📊 Arms analyzed: {list(report_data['arms'].keys())}")
    print(f"🎯 Winner: {report_data['summary'].get('winner', 'No clear winner')}")
    print(f"📋 Recommendations: {len(report_data['recommendations'])}")
    
    print("\n📁 Reports saved in ./reports/ directory:")
    print("  - CSV: Detailed numeric data")
    print("  - Markdown: Human-readable summary")
    print("  - JSON: Complete structured data")
