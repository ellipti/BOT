# strategies/__init__.py can be empty
