# Test file for pre-commit hooks
x = 1 + 2  # Should be formatted to x = 1 + 2
print(x)
